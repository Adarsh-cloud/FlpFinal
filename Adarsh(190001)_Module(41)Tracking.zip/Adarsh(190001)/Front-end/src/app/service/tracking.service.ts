import { Injectable } from '@angular/core';
import { Orders } from '../models/Orders';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TrackingService {

  orders: Orders[];

  constructor(private http:HttpClient) {
    this.populateOrders().subscribe(data=>this.orders=data, error=>console.log(error));
  }

  populateOrders(): Observable<Orders[]> {
    return this.http.get<Orders[]>("http://localhost:6500/capstore/getAllOrders");
  }

  getOrders():Orders[] {
    return this.orders;
  }
}
