import { Injectable } from '@angular/core';
import { Transactions } from '../models/Transactions';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  transactions:Transactions[];
  constructor(private http:HttpClient) {
    this.populateTransactions().subscribe(data=>this.transactions=data, error=>console.log(error));
   }
  populateTransactions(): Observable<Transactions[]> {
    return this.http.get<Transactions[]>("http://localhost:6500/capstore//getAllTransactions");
  }
  getTransactions():Transactions[] {
    return this.transactions;
  }

}
