import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { TrackingComponent } from './tracking/tracking.component' ;
import { TransactionComponent } from './Transaction/transaction.component';


const routes: Routes = [
  {path:"", component: HomeComponent},
  {path:"tracking", component: TrackingComponent},
  {path:"transaction", component:TransactionComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
