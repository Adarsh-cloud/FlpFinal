export interface Transactions{
transactionType:string,
transactionMode:string,
amount:number,
transactionId:number
}
