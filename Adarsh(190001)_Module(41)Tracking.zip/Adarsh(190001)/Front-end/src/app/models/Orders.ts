export interface Orders {
  customerId: number;
  productId: number;
  merchantId: number;
  quantity: number;
  status: string;
}
