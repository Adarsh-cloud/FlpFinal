import { Component, OnInit } from '@angular/core';
import { Orders } from '../models/Orders';
import { TrackingService } from '../service/tracking.service';

@Component({
  selector: 'app-tracking',
  templateUrl: './tracking.component.html',
  styleUrls: ['./tracking.component.css']
})
export class TrackingComponent implements OnInit {

  orders: Orders[];

  constructor(private trackingService: TrackingService) { }

  ngOnInit() {
    this.orders=this.trackingService.getOrders();
  }

}
