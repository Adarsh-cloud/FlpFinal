import { Component, OnInit } from '@angular/core';
import { Transactions } from '../models/Transactions';
import { TransactionService } from '../service/transaction.service';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
  transactions:Transactions[];
  constructor(private transactionService:TransactionService) { }

  ngOnInit() {
    this.transactions=this.transactionService.getTransactions();
  }

}
