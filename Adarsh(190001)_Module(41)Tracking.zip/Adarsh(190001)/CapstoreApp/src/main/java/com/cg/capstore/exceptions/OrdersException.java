package com.cg.capstore.exceptions;

public class OrdersException extends Exception{

	private static final long serialVersionUID = 1L;
	
	public OrdersException() {
		super();
	}
	
	public OrdersException(String message) {
		super(message);
	}

}
