package com.cg.capstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapstoreAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapstoreAppApplication.class, args);
	}

}
