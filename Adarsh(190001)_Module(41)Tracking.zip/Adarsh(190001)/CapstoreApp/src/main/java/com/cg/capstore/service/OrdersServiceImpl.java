package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.beans.Orders;
import com.cg.capstore.dao.OrdersRepository;
import com.cg.capstore.exceptions.OrdersException;

@Service
public class OrdersServiceImpl implements OrdersService {

	@Autowired
	private OrdersRepository ordersRepository;

	@Override
	public List<Orders> getAllOrders() throws OrdersException {
		return ordersRepository.findAll();
	}

	@Override
	public List<Orders> addOrders(Orders orders) throws OrdersException {
		ordersRepository.save(orders);
		return getAllOrders();
	}

}
