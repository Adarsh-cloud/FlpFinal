package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.beans.Transaction;
import com.cg.capstore.dao.TransactionRepository;
import com.cg.capstore.exceptions.TransactionException;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionRepository transactionRepository;
	@Override
	public List<Transaction> getAllTransactions() throws TransactionException {
		return transactionRepository.findAll();
	}

	@Override
	public List<Transaction> addTransactions(Transaction transaction) throws TransactionException {
		transactionRepository.save(transaction);
		return getAllTransactions();
	}

}
