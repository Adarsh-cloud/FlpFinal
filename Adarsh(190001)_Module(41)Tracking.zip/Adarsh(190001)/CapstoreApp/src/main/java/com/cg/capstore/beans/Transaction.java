package com.cg.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Transaction {

	@Id
	@SequenceGenerator(name = "trans_id", sequenceName = "trans_id", initialValue = 90000, allocationSize = 1)
	@GeneratedValue(generator = "trans_id")
	private int transactionId;
	// Net Banking, card or cash
	private String transactionMode;
	private double amount;
	// Refund or Payment
	private String transactionType;

	public Transaction() {
		super();
	}

	public Transaction(int transactionId, String transactionMode, double amount, String transactionType) {
		super();
		this.transactionId = transactionId;
		this.transactionMode = transactionMode;
		this.amount = amount;
		this.transactionType = transactionType;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionMode() {
		return transactionMode;
	}

	public void setTransactionMode(String transactionMode) {
		this.transactionMode = transactionMode;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionMode=" + transactionMode + ", amount=" + amount
				+ ", transactionType=" + transactionType + "]";
	}
}
