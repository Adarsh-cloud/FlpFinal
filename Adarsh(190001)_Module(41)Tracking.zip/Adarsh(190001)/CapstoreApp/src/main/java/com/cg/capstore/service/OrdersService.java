package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.beans.Orders;
import com.cg.capstore.exceptions.OrdersException;

public interface OrdersService {

	List<Orders> getAllOrders() throws OrdersException;

	List<Orders> addOrders(Orders orders) throws OrdersException;
}
