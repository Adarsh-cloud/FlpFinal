package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.beans.Transaction;
import com.cg.capstore.exceptions.TransactionException;

public interface TransactionService {

	List<Transaction> getAllTransactions() throws TransactionException;
	
	List<Transaction> addTransactions(Transaction transaction) throws TransactionException;
}
